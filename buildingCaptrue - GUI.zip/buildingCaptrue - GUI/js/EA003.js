$(function() {
	
	var delImg = "";
	
	// URL関連レコード数取得
	var urlRedCount = document.getElementById('urlResult').children.length;
	// URLレコード追加存在しないの場合、
	if (urlRedCount == 0) {
		// INDEX設定
		var urlRedIndex = 0;
		$("#urlIndex").val(urlRedIndex);
	} else {
		$("#urlIndex").val(urlRedCount);
	}
	
	// 登録FLG
	var updateFlg = $("#updateFlg").val();
	// 登録完了の場合
	if (updateFlg == 1){
		$('#endLog').modal({
			keyboard: false,backdrop:false
			  });
	}
	// 1:登録 2:異常
	if (updateFlg == 2){
		
		var drawArr = new Array();
		// 手描画像JSON
		var drawJson =  $("#drawJson").val();
		var drawObj = JSON.parse(drawJson);
		for (var i = 0; i < drawObj.length; i++) {
			var src = drawObj[i];
			drawArr.push(src);
		}
		for (var i = 0; i < drawArr.length; i++) {
			var temp = 0;
			compress(drawArr[i], i);
			$("#imgId").val(i);
		}
		
		var outerArr = new Array();
		// 外観画像JSON
		var outerJson =  $("#outerJson").val();
		var outerObj = JSON.parse(outerJson);
		for (var i = 0; i < outerObj.length; i++) {
			var src = outerObj[i];
			outerArr.push(src);
		}
		for (var i = 0; i < outerArr.length; i++) {
			var temp = 0;
			compressOuter(outerArr[i], i);
			$("#outerimgId").val(i);
		}
		
		
		var innerArr = new Array();
		// 内観画像JSON
		var innerJson =  $("#innerJson").val();
		var innerObj = JSON.parse(innerJson);
		for (var i = 0; i < innerObj.length; i++) {
			var src = innerObj[i];
			innerArr.push(src);
		}
		for (var i = 0; i < innerArr.length; i++) {
			var temp = 0;
			compressInner(innerArr[i], i);
			$("#innerimgId").val(i);
		}

		var planeArr = new Array();
		// 間取画像JSON
		var planeJson =  $("#planeJson").val();
		var planeObj = JSON.parse(planeJson);
		for (var i = 0; i < planeObj.length; i++) {
			var src = planeObj[i];
			planeArr.push(src);
		}
		for (var i = 0; i < planeArr.length; i++) {
			var temp = 0;
			compressPlane(planeArr[i], i);
			$("#planeimgId").val(i);
		}
		
		var overlookArr = new Array();
		// 俯瞰画像JSON
		var overlookJson =  $("#overlookJson").val();
		var overlookObj = JSON.parse(overlookJson);
		for (var i = 0; i < overlookObj.length; i++) {
			var src = overlookObj[i];
			overlookArr.push(src);
		}
		for (var i = 0; i < overlookArr.length; i++) {
			var temp = 0;
			compressOverlook(overlookArr[i], i);
			$("#overlookimgId").val(i);
		}
		
		var sideArr = new Array();
		// 立面画像JSON
		var sideJson =  $("#sideJson").val();
		var sideObj = JSON.parse(sideJson);
		for (var i = 0; i < sideObj.length; i++) {
			var src = sideObj[i];
			sideArr.push(src);
		}
		for (var i = 0; i < sideArr.length; i++) {
			var temp = 0;
			compressSide(sideArr[i], i);
			$("#sideimgId").val(i);
		}
		
		var pathArr = new Array();
		// 四面画像JSON
		var pathJson =  $("#pathJson").val();
		var pathObj = JSON.parse(pathJson);
		for (var i = 0; i < pathObj.length; i++) {
			var src = pathObj[i];
			pathArr.push(src);
		}
		for (var i = 0; i < pathArr.length; i++) {
			var temp = 0;
			compressPath(pathArr[i], i);
			$("#pathimgId").val(i);
		}
	}
	

	// URL関連レコード数取得
	var cordinateRedCount = document.getElementById('cordinateResult').children.length;
	// URLレコード追加存在しないの場合、
	if (cordinateRedCount == 0) {
		// INDEX設定
		var cordinateRedIndex = 0;
		$("#cordinateIndex").val(cordinateRedIndex);
		// レコード追加
		addcordinateTableRow();
	} else {
		$("#cordinateIndex").val(cordinateRedCount);
	}
	
	// 手描画像
	var drawImageInput = document.getElementById("drawImageList");
	// 手描画像
	var addDrawImg = document.getElementById("addDrawImg");
	$("#drawAdd").bind("click", function(event) {
		
		var temp = Number($("#imgId").val()) + Number(1);
		addDrawFile(temp);
		// 手描画像
		var imageInput = document.getElementById("drawImageList"+ temp);
		imageInput.addEventListener('change', readDrawFile, false);
		imageInput.click();
	});

	var urlArr = [];
	var index = 1;
	$("#imgId").val(index);

	function readDrawFile() {
		var files = this.files;
		for (var i = 0; i < files.length; i++) {
			(function() {
				var temp = 0;
				if (files.length>1) {
					temp = Number($("#imgId").val()) + Number(i);
				} else {
					temp = Number($("#imgId").val()) + Number(1);
				}
	
				if (!/image\/\w+/.test(files[i].type)) {
					return false;
				}
				var reader = new FileReader();
				reader.readAsDataURL(files[i]);
				reader.onload = function(e) {
					compress(this.result, temp);
					$("#imgId").val(temp);
				};
			})()
		}
	}
	
	function compress(res, index) {
		var img = new Image();
		var maxHeight = 200;
		img.onload = function() {
			var canvas = document.createElement('canvas');
			var ctx = canvas.getContext('2d');
			if (img.height > maxHeight) {
				img.width *= maxHeight / img.height;
				img.height = maxHeight;
			}
			canvas.height = img.height;
			canvas.width = img.width;
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			var dataUrl = canvas.toDataURL('image/jpg', 1);
			var div = document.createElement('div');
			var span = document.createElement('span');
			var input = document.createElement('input');
			div.setAttribute('class', 'outbox');
			div.setAttribute('id', 'outbox'+ index);
			div.setAttribute('name', 'InsertPlanCondition.drawImageList['+ index +'].imageUrl');
			span.setAttribute('class', 'delete');
			span.setAttribute('data-value', index++);
			span.setAttribute('id', 'delBox'+ index);
			
			input.setAttribute('type', 'hidden');
			input.setAttribute('id', 'hidDraw'+ index);
			input.setAttribute('name', 'hidDraw'+ index);
			input.setAttribute('value', res);

			var img1 = document.createElement('img');
			img1.src = dataUrl; 
			img1.id = 'drawimg'+ index;
			div.appendChild(img1);
			div.appendChild(span);
			div.appendChild(input);
			addDrawImg.before(div);
			urlArr.push(dataUrl);
		}
		img.src = res;
	}

	// 外観画像
	var addOuterImg = document.getElementById("addOuterImg");
	$("#outerAdd").bind("click", function(event) {
		
		var temp = Number($("#outerimgId").val()) + Number(1);
		addOuterFile(temp);
		// 外観画像
		var imageInput = document.getElementById("outerImageList"+ temp);
		imageInput.addEventListener('change', readOuterFile, false);
		imageInput.click();
	});
	
	var outerurlArr = [];
	var outerIndex = 1;
	$("#outerimgId").val(outerIndex);

	function readOuterFile(files) {
		var files = this.files;
		for (var i = 0; i < files.length; i++) {
			(function() {
				var temp = 0;
				if (files.length>1) {
					temp = Number($("#outerimgId").val()) + Number(i);
				} else {
					temp = Number($("#outerimgId").val()) + Number(1);
				}
	
				if (!/image\/\w+/.test(files[i].type)) {
					return false;
				}
				var reader = new FileReader();
				reader.readAsDataURL(files[i]);
				reader.onload = function(e) {
					compressOuter(this.result, temp);
					$("#outerimgId").val(temp);
				};
			})()
		}
	}
	
	function compressOuter(res, index) {
		var img = new Image();
		var maxHeight = 200;
		img.onload = function() {
			var canvas = document.createElement('canvas');
			var ctx = canvas.getContext('2d');
			if (img.height > maxHeight) {
				img.width *= maxHeight / img.height;
				img.height = maxHeight;
			}
			canvas.height = img.height;
			canvas.width = img.width;
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			var dataUrl = canvas.toDataURL('image/jpg', 1);
			var div = document.createElement('div');
			var span = document.createElement('span');
			var input = document.createElement('input');
			div.setAttribute('class', 'outbox');
			div.setAttribute('id', 'outerBox'+ index);
			div.setAttribute('name', 'InsertPlanCondition.outerImageList['+ index +'].imageUrl');
			span.setAttribute('class', 'delete');
			span.setAttribute('data-value', index++);
			span.setAttribute('id', 'delBox'+ index);
			
			input.setAttribute('type', 'hidden');
			input.setAttribute('id', 'hidOuter'+ index);
			input.setAttribute('name', 'hidOuter'+ index);
			input.setAttribute('value', res);

			var img1 = document.createElement('img');
			img1.src = dataUrl; 
			img1.id = 'outerimg'+ index;
			div.appendChild(img1);
			div.appendChild(span);
			div.appendChild(input);
			addOuterImg.before(div);
			outerurlArr.push(dataUrl);

		}
		img.src = res;
	}
	
	// 内観画像
	var addInnerImg = document.getElementById("addInnerImg");
	$("#innerAdd").bind("click", function(event) {
		
		var temp = Number($("#innerimgId").val()) + Number(1);
		addInnerFile(temp);
		// 内観画像
		var imageInput = document.getElementById("innerImageList"+ temp);
		imageInput.addEventListener('change', readInnerFile, false);
		imageInput.click();
	});
	
	var innerurlArr = [];
	var innerIndex = 1;
	$("#innerimgId").val(innerIndex);

	function readInnerFile(files) {
		var files = this.files;
		for (var i = 0; i < files.length; i++) {
			(function() {
				var temp = 0;
				if (files.length>1) {
					temp = Number($("#innerimgId").val()) + Number(i);
				} else {
					temp = Number($("#innerimgId").val()) + Number(1);
				}
	
				if (!/image\/\w+/.test(files[i].type)) {
					return false;
				}
				var reader = new FileReader();
				reader.readAsDataURL(files[i]);
				reader.onload = function(e) {
					compressInner(this.result, temp);
					$("#innerimgId").val(temp);
				};
			})()
		}
	}
	
	function compressInner(res, index) {
		var img = new Image();
		var maxHeight = 200;
		img.onload = function() {
			var canvas = document.createElement('canvas');
			var ctx = canvas.getContext('2d');
			if (img.height > maxHeight) {
				img.width *= maxHeight / img.height;
				img.height = maxHeight;
			}
			canvas.height = img.height;
			canvas.width = img.width;
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			var dataUrl = canvas.toDataURL('image/jpg', 1);
			var div = document.createElement('div');
			var span = document.createElement('span');
			var input = document.createElement('input');
			div.setAttribute('class', 'outbox');
			div.setAttribute('id', 'innerBox'+ index);
			div.setAttribute('name', 'InsertPlanCondition.innerImageList['+ index +'].imageUrl');
			span.setAttribute('class', 'delete');
			span.setAttribute('data-value', index++);
			span.setAttribute('id', 'delBox'+ index);
			
			input.setAttribute('type', 'hidden');
			input.setAttribute('id', 'hidInner'+ index);
			input.setAttribute('name', 'hidInner'+ index);
			input.setAttribute('value', res);
			
			var img1 = document.createElement('img');
			img1.src = dataUrl; 
			img1.id = 'innerimg'+ index;
			div.appendChild(img1);
			div.appendChild(span);
			div.appendChild(input);
			addInnerImg.before(div);
			innerurlArr.push(dataUrl);

		}
		img.src = res;
	}
	
	// 間取画像
	var addPlaneImg = document.getElementById("addPlaneImg");
	$("#planeAdd").bind("click", function(event) {
		
		var temp = Number($("#planeimgId").val()) + Number(1);
		addPlaneFile(temp);
		// 間取画像
		var imageInput = document.getElementById("planeImageList"+ temp);
		imageInput.addEventListener('change', readPlaneFile, false);
		imageInput.click();
	});
	
	var planeurlArr = [];
	var planeIndex = 1;
	$("#planeimgId").val(planeIndex);

	function readPlaneFile(files) {
		var files = this.files;
		for (var i = 0; i < files.length; i++) {
			(function() {
				var temp = 0;
				if (files.length>1) {
					temp = Number($("#planeimgId").val()) + Number(i);
				} else {
					temp = Number($("#planeimgId").val()) + Number(1);
				}
	
				if (!/image\/\w+/.test(files[i].type)) {
					return false;
				}
				var reader = new FileReader();
				reader.readAsDataURL(files[i]);
				reader.onload = function(e) {
					compressPlane(this.result, temp);
					$("#planeimgId").val(temp);
				};
			})()
		}
	}
	
	function compressPlane(res, index) {
		var img = new Image();
		var maxHeight = 200;
		img.onload = function() {
			var canvas = document.createElement('canvas');
			var ctx = canvas.getContext('2d');
			if (img.height > maxHeight) {
				img.width *= maxHeight / img.height;
				img.height = maxHeight;
			}
			canvas.height = img.height;
			canvas.width = img.width;
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			var dataUrl = canvas.toDataURL('image/jpg', 1);
			var div = document.createElement('div');
			var span = document.createElement('span');
			var input = document.createElement('input');
			div.setAttribute('class', 'outbox');
			div.setAttribute('id', 'planeBox'+ index);
			div.setAttribute('name', 'InsertPlanCondition.planeImageList['+ index +'].imageUrl');
			span.setAttribute('class', 'delete');
			span.setAttribute('data-value', index++);
			span.setAttribute('id', 'delBox'+ index);
			
			input.setAttribute('type', 'hidden');
			input.setAttribute('id', 'hidPlane'+ index);
			input.setAttribute('name', 'hidPlane'+ index);
			input.setAttribute('value', res);
			
			var img1 = document.createElement('img');
			img1.src = dataUrl; 
			img1.id = 'planeimg'+ index;
			div.appendChild(img1);
			div.appendChild(span);
			div.appendChild(input);
			addPlaneImg.before(div);
			planeurlArr.push(dataUrl);

		}
		img.src = res;
	}

	// 俯瞰画像
	var addOverlookImg = document.getElementById("addOverlookImg");
	$("#overlookAdd").bind("click", function(event) {
		
		var temp = Number($("#overlookimgId").val()) + Number(1);
		addOverlookFile(temp);
		// 俯瞰画像
		var imageInput = document.getElementById("overlookImageList"+ temp);
		imageInput.addEventListener('change', readOverlookFile, false);
		imageInput.click();
	});
	
	var overlookurlArr = [];
	var overlookIndex = 1;
	$("#overlookimgId").val(overlookIndex);

	function readOverlookFile(files) {
		var files = this.files;
		for (var i = 0; i < files.length; i++) {
			(function() {
				var temp = 0;
				if (files.length>1) {
					temp = Number($("#overlookimgId").val()) + Number(i);
				} else {
					temp = Number($("#overlookimgId").val()) + Number(1);
				}
	
				if (!/image\/\w+/.test(files[i].type)) {
					return false;
				}
				var reader = new FileReader();
				reader.readAsDataURL(files[i]);
				reader.onload = function(e) {
					compressOverlook(this.result, temp);
					$("#overlookimgId").val(temp);
				};
			})()
		}
	}
	
	function compressOverlook(res, index) {
		var img = new Image();
		var maxHeight = 200;
		img.onload = function() {
			var canvas = document.createElement('canvas');
			var ctx = canvas.getContext('2d');
			if (img.height > maxHeight) {
				img.width *= maxHeight / img.height;
				img.height = maxHeight;
			}
			canvas.height = img.height;
			canvas.width = img.width;
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			var dataUrl = canvas.toDataURL('image/jpg', 1);
			var div = document.createElement('div');
			var span = document.createElement('span');
			var input = document.createElement('input');
			div.setAttribute('class', 'outbox');
			div.setAttribute('id', 'overlookBox'+ index);
			div.setAttribute('name', 'InsertPlanCondition.overlookImageList['+ index +'].imageUrl');
			span.setAttribute('class', 'delete');
			span.setAttribute('data-value', index++);
			span.setAttribute('id', 'delBox'+ index);
			
			input.setAttribute('type', 'hidden');
			input.setAttribute('id', 'hidOverlook'+ index);
			input.setAttribute('name', 'hidOverlook'+ index);
			input.setAttribute('value', res);
			
			var img1 = document.createElement('img');
			img1.src = dataUrl; 
			img1.id = 'overlookimg'+ index;
			div.appendChild(img1);
			div.appendChild(span);
			div.appendChild(input);
			addOverlookImg.before(div);
			overlookurlArr.push(dataUrl);

		}
		img.src = res;
	}
	
	// 立面画像
	var addSideImg = document.getElementById("addSideImg");
	$("#sideAdd").bind("click", function(event) {
		
		var temp = Number($("#sideimgId").val()) + Number(1);
		addSideFile(temp);
		// 立面画像
		var imageInput = document.getElementById("sideImageList"+ temp);
		imageInput.addEventListener('change', readSideFile, false);
		imageInput.click();
	});
	
	var sideurlArr = [];
	var sideIndex = 1;
	$("#sideimgId").val(sideIndex);

	function readSideFile(files) {
		var files = this.files;
		for (var i = 0; i < files.length; i++) {
			(function() {
				var temp = 0;
				if (files.length>1) {
					temp = Number($("#sideimgId").val()) + Number(i);
				} else {
					temp = Number($("#sideimgId").val()) + Number(1);
				}
	
				if (!/image\/\w+/.test(files[i].type)) {
					return false;
				}
				var reader = new FileReader();
				reader.readAsDataURL(files[i]);
				reader.onload = function(e) {
					compressSide(this.result, temp);
					$("#sideimgId").val(temp);
				};
			})()
		}
	}
	
	function compressSide(res, index) {
		var img = new Image();
		var maxHeight = 200;
		img.onload = function() {
			var canvas = document.createElement('canvas');
			var ctx = canvas.getContext('2d');
			if (img.height > maxHeight) {
				img.width *= maxHeight / img.height;
				img.height = maxHeight;
			}
			canvas.height = img.height;
			canvas.width = img.width;
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			var dataUrl = canvas.toDataURL('image/jpg', 1);
			var div = document.createElement('div');
			var span = document.createElement('span');
			var input = document.createElement('input');
			div.setAttribute('class', 'outbox');
			div.setAttribute('id', 'sideBox'+ index);
			div.setAttribute('name', 'InsertPlanCondition.sideImageList['+ index +'].imageUrl');
			span.setAttribute('class', 'delete');
			span.setAttribute('data-value', index++);
			span.setAttribute('id', 'delBox'+ index);
			
			input.setAttribute('type', 'hidden');
			input.setAttribute('id', 'hidSide'+ index);
			input.setAttribute('name', 'hidSide'+ index);
			input.setAttribute('value', res);
			
			var img1 = document.createElement('img');
			img1.src = dataUrl; 
			img1.id = 'sideimg'+ index;
			div.appendChild(img1);
			div.appendChild(span);
			div.appendChild(input);
			addSideImg.before(div);
			sideurlArr.push(dataUrl);

		}
		img.src = res;
	}
	
	// 四面画像
	var addPathImg = document.getElementById("addPathImg");
	$("#pathAdd").bind("click", function(event) {
		
		var temp = Number($("#pathimgId").val()) + Number(1);
		addPathFile(temp);
		// 四面画像
		var imageInput = document.getElementById("pathImageList"+ temp);
		imageInput.addEventListener('change', readPathFile, false);
		imageInput.click();
	});
	
	var pathurlArr = [];
	var pathIndex = 1;
	$("#pathimgId").val(pathIndex);

	function readPathFile(files) {
		var files = this.files;
		for (var i = 0; i < files.length; i++) {
			(function() {
				var temp = 0;
				if (files.length>1) {
					temp = Number($("#pathimgId").val()) + Number(i);
				} else {
					temp = Number($("#pathimgId").val()) + Number(1);
				}
	
				if (!/image\/\w+/.test(files[i].type)) {
					return false;
				}
				var reader = new FileReader();
				reader.readAsDataURL(files[i]);
				reader.onload = function(e) {
					compressPath(this.result, temp);
					$("#pathimgId").val(temp);
				};
			})()
		}
	}
	
	function compressPath(res, index) {
		var img = new Image();
		var maxHeight = 200;
		img.onload = function() {
			var canvas = document.createElement('canvas');
			var ctx = canvas.getContext('2d');
			if (img.height > maxHeight) {
				img.width *= maxHeight / img.height;
				img.height = maxHeight;
			}
			canvas.height = img.height;
			canvas.width = img.width;
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			var dataUrl = canvas.toDataURL('image/jpg', 1);
			var div = document.createElement('div');
			var span = document.createElement('span');
			var input = document.createElement('input');
			div.setAttribute('class', 'outbox');
			div.setAttribute('id', 'pathBox'+ index);
			div.setAttribute('name', 'InsertPlanCondition.pathImageList['+ index +'].imageUrl');
			span.setAttribute('class', 'delete');
			span.setAttribute('data-value', index++);
			span.setAttribute('id', 'delBox'+ index);
			
			input.setAttribute('type', 'hidden');
			input.setAttribute('id', 'hidPath'+ index);
			input.setAttribute('name', 'hidPath'+ index);
			input.setAttribute('value', res);
			
			var img1 = document.createElement('img');
			img1.src = dataUrl; 
			img1.id = 'pathimg'+ index;
			div.appendChild(img1);
			div.appendChild(span);
			div.appendChild(input);
			addPathImg.before(div);
			pathurlArr.push(dataUrl);

		}
		img.src = res;
	}
	
	$('#btn_insert').bind("click", function(event) {
		$("#updateFlg").val('0');
		// 手描画像
		var drawImgSrc= $("#previewImgdraw input[id^='hidDraw']");
		var drawimgUrl = "";
		drawImgSrc.each(function() {
			var src = $(this).attr('value');
			if (drawimgUrl =="") {
				drawimgUrl = src;
			} else {
				drawimgUrl = drawimgUrl + "," + src;
			}
			$("#drawImageSrcList").val(drawimgUrl);
		  });
		
		// 外観画像
		var outerImgSrc= $("#previewImgouter input[id^='hidOuter']");
		var outerimgUrl = "";
		outerImgSrc.each(function() {
			var src = $(this).attr('value');
			if (outerimgUrl =="") {
				outerimgUrl = src;
			} else {
				outerimgUrl = outerimgUrl + "," + src;
			}
			$("#outerImageSrcList").val(outerimgUrl);
		  });
		
		// 内観画像
		var innerImgSrc= $("#previewImginner input[id^='hidInner']");
		var innerimgUrl = "";
		innerImgSrc.each(function() {
			var src = $(this).attr('value');
			if (innerimgUrl =="") {
				innerimgUrl = src;
			} else {
				innerimgUrl = innerimgUrl + "," + src;
			}
			$("#innerImageSrcList").val(innerimgUrl);
		  });
		
		// 間取画像
		var planeImgSrc= $("#previewImgplane input[id^='hidPlane']");
		var planeimgUrl = "";
		planeImgSrc.each(function() {
			var src = $(this).attr('value');
			if (planeimgUrl =="") {
				planeimgUrl = src;
			} else {
				planeimgUrl = planeimgUrl + "," + src;
			}
			$("#planeImageSrcList").val(planeimgUrl);
		  });
		
		// 俯瞰画像
		var overlookImgSrc= $("#previewImgoverlook input[id^='hidOverlook']");
		var overlookimgUrl = "";
		overlookImgSrc.each(function() {
			var src = $(this).attr('value');
			if (overlookimgUrl =="") {
				overlookimgUrl = src;
			} else {
				overlookimgUrl = overlookimgUrl + "," + src;
			}
			$("#overlookImageSrcList").val(overlookimgUrl);
		  });
		
		// 立面画像
		var sideImgSrc= $("#previewImgside input[id^='hidSide']");
		var sideimgUrl = "";
		sideImgSrc.each(function() {
			var src = $(this).attr('value');
			if (sideimgUrl =="") {
				sideimgUrl = src;
			} else {
				sideimgUrl = sideimgUrl + "," + src;
			}
			$("#sideImageSrcList").val(sideimgUrl);
		  });
		
		// 四面画像
		var pathImgSrc= $("#previewImgpath input[id^='hidPath']");
		var pathimgUrl = "";
		pathImgSrc.each(function() {
			var src = $(this).attr('value');
			if (pathimgUrl =="") {
				pathimgUrl = src;
			} else {
				pathimgUrl = pathimgUrl + "," + src;
			}
			$("#pathImageSrcList").val(pathimgUrl);
		});
		
		if($("#planName").val() == ""){
			hideMask();
			$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML="「プラン名称」フィールドを入力してください。";
			$("#messageDialog").modal("toggle");
			return false;
		}
		if($("#totalFloorArea").val() == ""){
			hideMask();
			$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML="「延床面積」フィールドを入力してください。";
			$("#messageDialog").modal("toggle");
			return false;
		}
		if($("#hoseArea").val() == ""){
			hideMask();
			$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML="「建築面積」フィールドを入力してください。";
			$("#messageDialog").modal("toggle");
			return false;
		}
		if($("#housePrice").val() == ""){
			hideMask();
			$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML="「建物金額」フィールドを入力してください。";
			$("#messageDialog").modal("toggle");
			return false;
		}
		
		if(!checkNumberWithModal("延床面積",deleteComma($("#totalFloorArea").val()),6,3,"checkLog")){
			event.stopPropagation();
			return false;
		}
		
		if(!checkNumberWithModal("建築面積",deleteComma($("#hoseArea").val()),6,3,"checkLog")){
			event.stopPropagation();
			return false;
		}
		
		if(!checkNumberWithModal("建物金額",deleteComma($("#housePrice").val()),13,0,"checkLog")){
			event.stopPropagation();
			return false;
		}

		$("#totalFloorArea")[0].dataset["totalFloorArea"]=deleteComma($("#totalFloorArea").val());
		$("#hoseArea")[0].dataset["hoseArea"]=deleteComma($("#hoseArea").val());
		$("#housePrice")[0].dataset["housePrice"]=deleteComma($("#housePrice").val());
		
		var lineNo = 1;
		var errorFlg = 0;
		$("#para_table_cordinate input[name$='cordinateX']").each(function() {
			var chkCordinateX = this.value;
			if(!checkNumberWithModal("座標設定画面に明細行（" + lineNo +"）のX座標" ,deleteComma(chkCordinateX),3,3,"checkLog")){
				event.stopPropagation();
				errorFlg = 1;
			}
			lineNo= Number(lineNo) +  Number(1);
		})
		if (errorFlg == 1) {
			return false;
		}
		errorFlg= 0;

		lineNo = 1;
		errorFlg = 0;
		$("#para_table_cordinate input[name$='cordinateY']").each(function() {
			var chkCordinateY = this.value;
			if(!checkNumberWithModal("座標設定画面に明細行（" + lineNo +"）のY座標" ,deleteComma(chkCordinateY),3,3,"checkLog")){
				event.stopPropagation();
				errorFlg = 1;
			}
			lineNo= Number(lineNo) +  Number(1);
		})
		if (errorFlg == 1) {
			return false;
		}
		
		// 確認LOG
		$('#insertLog').modal({
			keyboard: false,backdrop:false
			  });
		
		return false;
	});
	
	$("#insert").click(
	function() {
		var form = $("#ea003");
		form.attr("action", "./addPlan");
		form.submit();
	})
	
	$("#btn_cancel").on("click", function() {
		hideMask();
	})

	$("div[id^=previewImg]").on('click','span', function() {
		var index = $(this).attr('data-value');
		delImg = $(this);
		$('#deleteLog').modal({
			keyboard: false,backdrop:false
			  });
	})

	$("#delete").click(
	function() {
		delImg.parent().remove();
	})


	$("div[id^=previewImg]").on('click','img', function() {
				if ($(this).attr('id') != "drawAdd"
						&& $(this).attr('id') != "outerAdd"
						&& $(this).attr('id') != "innerAdd"
						&& $(this).attr('id') != "planeAdd"
						&& $(this).attr('id') != "overlookAdd"
						&& $(this).attr('id') != "sideAdd"
						&& $(this).attr('id') != "pathAdd") {

					$('#imgInModalID').attr('src', $(this).next().next().attr('value'));
					$('#imgModal').modal({
						keyboard : false
					});
				}
	})

	// URL設定ボタンを押下
	$("#btn_setUrl").click(function () {
		$('#setUrlModal').modal({
			keyboard: false,backdrop:false
			  });
	})

	// URLレコード追加
	$("#btn_addUrl").bind("click", function(event) {
		addUrlTableRow();
	});

	// 座標設定ボタンを押下
	$("#btn_setCoordinate").click(function () {
			$('#setCoordinateModal').modal({
				keyboard: false,backdrop:false
				  });
		})
	
	$('#para_table_coordinate').on('click', 'button', function() {
		var td = $(this);
		td.parents("tr").remove();
	})

	// 座標レコード追加
	$("#btn_addCoordinate").bind("click", function(event) {
		// レコード追加
		addcordinateTableRow();
	});
	
	// 確認メッセージ
	var modalFlg = $("#modalFlg").val();
	if (modalFlg == "true") {
		$("#urlUpdateConfirm").modal({
			keyboard : false,backdrop:false
		});
	}
	
	// URL削除ボタン
	$('#para_table_url').on('click', 'button', function() {
		var td = $(this);
		td.parent().parent().remove();
		var title= $("#para_table_url input[name$='title']");
		
		var index = 0;
		title.each(function() {
			$(this).attr("name", "urlList[" + index + "].title");
			index++;
		  });
		
		var url= $("#para_table_url input[name$='url']");
		
		index = 0;
		url.each(function() {
			$(this).attr("name", "urlList[" + index + "].url");
			index++;
		});
		
		var urlIndex = $("#urlIndex").val();
		urlIndex = Number(urlIndex) - Number(1);
		$("#urlIndex").val(urlIndex);
	})

	geturlHidList();
	$("#btn_confirmUrl").on("click", function() {
		geturlHidList();
	})

	$("#btn_cancelUrl").on("click", function() {
		$("#urlResult > tr").remove();
		$("#urlIndex").val(0);
		urlHidList.forEach(function(element,index) {
			addUrlTableRow();
			$("[name='urlList["+ index+ "].title']").val(element.x);
			$("[name='urlList["+ index+ "].url']").val(element.y);
		})
	})
	
	// 座標削除ボタン
	$('#para_table_cordinate').on('click', 'button', function() {
		var td = $(this);
		td.parent().parent().remove();

		var title= $("#para_table_cordinate input[name$='cordinateX']");
		
		var index = 0;
		title.each(function() {
			$(this).attr("name", "cordinateList[" + index + "].cordinateX");
			index++;
		  });
		
		var url= $("#para_table_cordinate input[name$='cordinateY']");
		
		index = 0;
		url.each(function() {
			$(this).attr("name", "cordinateList[" + index + "].cordinateY");
			index++;
		});
		
		var cordinateIndex = $("#cordinateIndex").val();
		cordinateIndex = Number(cordinateIndex) - Number(1);
		$("#cordinateIndex").val(cordinateIndex);
	})

	getCoordinateList();
	$("#btn_confirmCoordinate").on("click", function() {
		getCoordinateList();
	})

	$("#btn_cancelCoordinate").on("click", function() {
		$("#cordinateResult > tr").remove();
		$("#cordinateIndex").val(0);
		coordinateList.forEach(function(element,index) {
			addcordinateTableRow();
			$("[name='cordinateList["+ index+ "].cordinateX']").val(element.x);
			$("[name='cordinateList["+ index+ "].cordinateY']").val(element.y);
		})
	})
});

/**
 * 
 * 座標一覧作成
 * 
 */
function getCoordinateList() {
	coordinateList = [];
	$("[name$='cordinateX']").each(function() {
		let point = new Point();
		point.x = this.value;
		point.y = $("[name='" + this.name.replace('cordinateX', 'cordinateY') + "']").val();
		coordinateList.push(point);
	})
}

/**
 * 
 * URL一覧作成
 * 
 */
function geturlHidList() {
	urlHidList = [];
	$("[name$='title']").each(function() {
		let point = new Point();
		point.x = this.value;
		point.y = $("[name='" + this.name.replace('title', 'url') + "']").val();
		urlHidList.push(point);
	})
}

/**
 * 
 * URLレコード追加
 * 
 */
function addUrlTableRow()
{
	var urlIndex = $("#urlIndex").val();  
	var table = $("#para_table_url");
	
	var tr = $("<tr>"
			+ "<td style='text-align: center;width: 35%; word-break: break-all'>"
			+ "<input type='text' class='form-control'"+" name='urlList["+ urlIndex +"].title' placeholder='タイトル設定' maxlength='20'>"
			+ "</td>"
			+ "<td style='text-align: center;width: 45%; word-break: break-all'>"
			+ "<input type='text' class='form-control'"+" name='urlList["+ urlIndex +"].url' placeholder='URL設定' maxlength='200'>"
			+ "</td>"
			+ "<td style='text-align: center;width: 20%; word-break: break-all'><button type='button'  class='btn list-group-item-primary' id='btn_del' >"
			+ "削除" + "</button></td></tr>");
	
	table.append(tr);
	urlIndex = Number(urlIndex) + Number(1);
	$("#urlIndex").val(urlIndex);
}

/**
 * 
 * 座標レコード追加
 * 
 */
function addcordinateTableRow()
{
	var cordinateIndex = $("#cordinateIndex").val();  
	var table = $("#para_table_cordinate");
	
	var tr = $("<tr>"
			+ "<td style='text-align: center;width: 40%; word-break: break-all'>"
			+ "<input type='text' class='form-control'"+" name='cordinateList["+ cordinateIndex +"].cordinateX' placeholder='例：999.999' maxlength='7'>"
			+ "</td>"
			+ "<td style='text-align: center;width: 40%; word-break: break-all'>"
			+ "<input type='text' class='form-control'"+" name='cordinateList["+ cordinateIndex +"].cordinateY' placeholder='例：999.999' maxlength='7'>"
			+ "</td>"
			+ "<td style='text-align: center;width: 20%; word-break: break-all'><button type='button'  class='btn list-group-item-primary' id='btn_delCoordinate' >"
			+ "削除" + "</button></td></tr>");

	table.append(tr);
	cordinateIndex = Number(cordinateIndex) + Number(1);
	$("#cordinateIndex").val(cordinateIndex);
}

/**
 * 
 * ファイル追加
 * 
 */
function addDrawFile(temp)
{
	var div = $("#addDrawImg");
	var input = $("<input style='position:absolute;opacity:0;display:none;' type='file' name='drawImageList' id='drawImageList"+ temp +"' accept='image/gif,image/jpeg,image/x-png' multiple/>");
	div.append(input);
}

/**
 * 
 * ファイル追加
 * 
 */
function addOuterFile(temp)
{
	var div = $("#addOuterImg");
	var input = $("<input style='position:absolute;opacity:0;display:none;' type='file' name='outerImageList' id='outerImageList"+ temp +"' accept='image/gif,image/jpeg,image/x-png' multiple/>");
	div.append(input);
}

/**
 * 
 * ファイル追加
 * 
 */
function addInnerFile(temp)
{
	var div = $("#addInnerImg");
	var input = $("<input style='position:absolute;opacity:0;display:none;' type='file' name='innerImageList' id='innerImageList"+ temp +"' accept='image/gif,image/jpeg,image/x-png' multiple/>");
	div.append(input);
}

/**
 * 
 * ファイル追加
 * 
 */
function addPlaneFile(temp)
{
	var div = $("#addPlaneImg");
	var input = $("<input style='position:absolute;opacity:0;display:none;' type='file' name='planeImageList' id='planeImageList"+ temp +"' accept='image/gif,image/jpeg,image/x-png' multiple/>");
	div.append(input);
}

/**
 * 
 * ファイル追加
 * 
 */
function addOverlookFile(temp)
{
	var div = $("#addOverlookImg");
	var input = $("<input style='position:absolute;opacity:0;display:none;' type='file' name='overlookImageList' id='overlookImageList"+ temp +"' accept='image/gif,image/jpeg,image/x-png' multiple/>");
	div.append(input);
}

/**
 * 
 * ファイル追加
 * 
 */
function addSideFile(temp)
{
	var div = $("#addSideImg");
	var input = $("<input style='position:absolute;opacity:0;display:none;' type='file' name='sideImageList' id='sideImageList"+ temp +"' accept='image/gif,image/jpeg,image/x-png' multiple/>");
	div.append(input);
}

/**
 * 
 * ファイル追加
 * 
 */
function addPathFile(temp)
{
	var div = $("#addSideImg");
	var input = $("<input style='position:absolute;opacity:0;display:none;' type='file' name='pathImageList' id='pathImageList"+ temp +"' accept='image/gif,image/jpeg,image/x-png' multiple/>");
	div.append(input);
}

/**
 * 
 * 座標一覧
 * 
 */
var coordinateList = [];

/**
 * 
 * URL一覧
 * 
 */
var urlHidList = [];