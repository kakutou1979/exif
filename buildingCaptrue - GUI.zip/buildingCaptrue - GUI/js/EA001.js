$(function() {

	$("#btn_addUserAccount").bind("click", function(event) {

		var form = $("#take_picture");
		form.attr("action", "./addUserAccount");
		form.submit();
	});
	$("#btn_planInsert").bind("click", function(event) {

		var form = $("#take_picture");
		form.attr("action", "./planInsert");
		form.submit();
	});
	$("#priceSet").bind("click", function(event) {

		var form = $("#take_picture");
		form.attr("action", "./priceSet");
		form.submit();
	});
	
	$("#btn_planSelect").bind("click", function(event) {

		var form = $("#take_picture");
		form.attr("action", "./planSelect");
		form.submit();
	});
	
	$("#btn_urlSet").bind("click", function(event) {

		var form = $("#take_picture");
		form.attr("action", "./urlSet");
		form.submit();
	});
	
	$("#btn_mailSet").bind("click", function(event) {

		var form = $("#take_picture");
		form.attr("action", "./mailSet");
		form.submit();
	});
})