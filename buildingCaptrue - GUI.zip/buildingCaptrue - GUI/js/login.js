$(function() {
	if ($("#osVersionMessage").val() != "") {
		$("#alertMessageDialog").modal({
			keyboard : false,
			backdrop : false
		});
	}
})