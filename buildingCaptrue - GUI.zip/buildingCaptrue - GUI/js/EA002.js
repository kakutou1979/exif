$(function() {
	
	
	// 登録FLG
	var updateFlg = $("#updateFlg").val();
	// 登録完了の場合
	if (updateFlg == 1){
		$('#endLog').modal({
			keyboard: false,backdrop:false
			  });
	}
	
	if($("#errorFlg").val()=="true"){
	$("#messageLog").modal({
        keyboard: false
      });
	}

	$('#para_table').on('click', 'button', function() {
		var td = $(this);
		
		td.parent().parent().remove();

        var email= $("#para_table input[type='email']");
        
        var index = 0;
        email.each(function() {
            $(this).attr("name", "userList[" + index + "].userId");
            index++;
          });
        
        var password= $("#para_table input[type='password']");
        
        index = 0;
        password.each(function() {
            $(this).attr("name", "userList[" + index + "].password");
            index++;
          });
        var role= $("#para_table select");
        
        index = 0;
        role.each(function() {
            $(this).attr("name", "userList[" + index + "].role");
            index++;
          });
        
		var userIndex = $("#userIndex").val();
		userIndex = Number(userIndex) - Number(1);
		$("#userIndex").val(userIndex);
	})
	
	// レコード存在COUNT
	var recordCount = document.getElementById('userResult').children.length;
	// レコード追加存在しないの場合、
	if (recordCount == 0) {
		// INDEX設定
		var index = 0;
	    $("#userIndex").val(index);
		// レコード追加
		addTableRow();
	} else {
		$("#userIndex").val(recordCount);
	}
	
	$("#btn_addAccount")
			.bind(
					"click",
					function(event) {
						
						// レコード追加
						addTableRow();
					});

	$('#btn_submitUser').bind("click", function(event) {
		$("#updateFlg").val('0');

		var lineNo = 1;
		var errorFlg = 0;
		$("#userResult input[name$='userId']").each(function() {
			var chkUserId = this.value;
			
			var reg = /\w+[@]{1}\w+[.]\w+/;
			   if(!reg.test(chkUserId)){
					$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML="明細行「" + lineNo +"」の「ユーザID」にはメールアドレスの形式で入力してください.";
					$("#messageDialog").modal("toggle");
					event.stopPropagation();
					errorFlg = 1;
			 }
			lineNo= Number(lineNo) +  Number(1);
		})
		if (errorFlg == 1) {
			return false;
		}
		
		lineNo = 1;
		errorFlg = 0;
		$("#userResult input[name$='password']").each(function() {
			var chkPassword = this.value;
			   if(chkPassword == ""){
					$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML="明細行「" + lineNo +"」の「パスワード」フィールドを入力してください。";
					$("#messageDialog").modal("toggle");
					event.stopPropagation();
					errorFlg = 1;
			 }
			lineNo= Number(lineNo) +  Number(1);
		})
		if (errorFlg == 1) {
			return false;
		}

		// 確認LOG
		$('#updateLog').modal({
			keyboard: false,backdrop:false
			  });
		return false;
	});
	
	$("#btn_update").click(function() {
		// 重複ユーザ無視チェック
		if($("#insertOnly").is(":checked")){
			$("#insertOnlyParam").val("1");
		} else {
			$("#insertOnlyParam").val("0");
		}

		var form = $("#ea002");
		form.attr("action", "./updateUser");
		form.submit();
	})

})

/**
 * 
 * レコード追加
 * 
 */
function addTableRow()
{
	var userIndex = $("#userIndex").val();
	var table = $("#para_table");

	var tr = $("<tr>"
			+ "<td style='text-align:center;width: 40%; word-break: break-all'>"
			+ "<input type='email' class='form-control' "+ "name='userList["+ userIndex +"].userId' "+"placeholder='ユーザID設定' required th:value='${user.userId}' maxlength='100'>"
			+ "</td>"
			+ "<td style='text-align:center;width: 30%; word-break: break-all'>"
			+ "<input type='password' class='form-control' "+ "name='userList["+ userIndex +"].password' " +"placeholder='パスワード設定' required='required' th:value='${user.password}' maxlength='100'>"
			+ "</td>"
			+
			"<td style='text-align:center; width: 20%; word-break: break-all'>"
			+ "<select class='form-control'" + "name='userList["+ userIndex +"].role' th:value='${user.role}' " + ">"
			+ "<option th:selected='${user.role=='ADMIN'}' value='ADMIN'>"
			+ "ADMIN"
			+ "</option>"
			+ "<option th:selected='${user.role=='USER'}' value='USER'>"
			+ "USER"
			+ "</option>"
			+ "</select>"
			+ "</td>"
			+ "<td  class='col-sm-2' style='text-align:center; width: 10%; word-break: break-all'><button type='button' class='btn list-group-item-primary' id='btn_del' >"
			+ "削除" + "</button></td></tr>");
	table.append(tr);
    userIndex =  Number(userIndex) +  Number(1);
    $("#userIndex").val(userIndex);
}

