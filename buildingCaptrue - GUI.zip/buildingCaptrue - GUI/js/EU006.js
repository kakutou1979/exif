$(function() {

	// 履歴ID設定
	$("tr[id^='resultConditionTo']").bind("click", function() {
		var historyId = this.children[5].childNodes[2].value;
		$("#historyId").val(historyId);
		var form = $("#take_picture");
		form.attr("action", "../resultConditionTo");
		form.submit();
	});

	$(document).ready(function() {

		// 敷地金額(円)設定
		var groundPrice = $("#para_table label[name$='groundPrice']");
		groundPrice.each(function() {
			$(this).text(format($(this).text()));
		});

		// 建物金額(円)設定
		var housePrice = $("#para_table label[name$='housePrice']");
		housePrice.each(function() {
			$(this).text(format($(this).text()));
		});
	});
})
