
$(function() {
	var type = $("#type").val();
	var textContent = $("#textContent").val();
	
	// 登録FLG
	var updateFlg = $("#updateFlg").val();
	// 登録完了の場合
	if (updateFlg == 1){
		$('#endLog').modal({
			keyboard: false,backdrop:false
			  });
	}
	
	// 確認ボタン
	$("#confirm").on("click",function(event){
		
		if($("#textContent").val() == ""){
				$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML="「メール内容」フィールドを入力してください。";
				$("#messageDialog").modal("toggle");
				return false;
		}
		
		// 確認LOG
		$("#updateLog").modal({
			keyboard: false,backdrop:false
			  });
		return false;
	});
	
	// はいボタン
	$("#btn_update").click(function() {
		var form = $("#ea008");
		form.attr("action", "./mailSetConfirm");
		form.submit();
	})

	// 
	$("#type").on("change",function(event){
		var transferData = new TransferData();
		transferData.type = $("#type").val();
		var request = $.ajax({
			url : "./selectMail",
			method : "POST",
			data : JSON.stringify(transferData),
			dataType : "json",
			contentType : "application/json; charset=UTF-8"
		});

		request.done(function(tMail) {
			$("#textContent").val(tMail.textContent);
			});
	});

});

function TransferData() {
	this.type;

}
