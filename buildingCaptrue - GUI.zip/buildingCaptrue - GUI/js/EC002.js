$(function() {

	var divWidth = $("#divCarousel").width();
	var divHeight = $("#divCarousel").height();
	
	$("img[id^='imageCarousel']").each(function() {
		 $(this)[0].onload = function(){
			 var imgWidth = $(this)[0].width;
			 var imgHeight = $(this)[0].height;
			 var scaleWidth = imgWidth / divWidth;
			 var scaleHeight = imgHeight / divHeight;
			 
			 if(scaleWidth > scaleHeight){
				 $(this)[0].width = imgWidth / scaleWidth;
				 $(this)[0].height = imgHeight / scaleWidth;
			 } else {
				 $(this)[0].width = imgWidth / scaleHeight;
				 $(this)[0].height = imgHeight / scaleHeight;
			 }
		 }
	});

	// URLオープン
	$("a[id^='urlOpen']").bind("click", function() {
		var url = $(this).prop("name");
		window.open(url, "_blank", "menubar=no,location=no,resizable=no,scrollbars=yes,status=no");
	});

	// ローンシミュレーションオープン
	$("#loanOpen").bind("click", function() {
		var url = $(this).prop("name");
		window.open(url, "_blank", "menubar=no,location=no,resizable=no,scrollbars=yes,status=no");
	});

	var tempGroundPrice = "";
	var tempDismountAreaRadio = false;
	var tempDismountArea = "";
	var tempDismountPriceRadio = false;
	var tempDismountPrice = "";
	// 金額設定ボタン
	$("#setSumBtn").click(function() {
		tempGroundPrice = $("#groundPrice").val();
		tempDismountAreaRadio = $("#dismountAreaRadio").is(":checked");
		tempDismountArea = $("#dismountArea").val();
		tempDismountPriceRadio = $("#dismountPriceRadio").is(":checked");
		tempDismountPrice = $("#dismountPrice").val();
		$("#setSum").modal({
			keyboard : false,
			backdrop : false
		});
	});

	// キャンセルボタン
	$("#cancelSum").click(function() {
		$("#groundPrice").val(tempGroundPrice);
		$("#dismountAreaRadio").prop("checked", tempDismountAreaRadio);
		$("#dismountArea").prop("disabled", tempDismountPriceRadio);
		$("#dismountArea").val(tempDismountArea);
		$("#dismountPriceRadio").prop("checked", tempDismountPriceRadio);
		$("#dismountPrice").prop("disabled", tempDismountAreaRadio);
		$("#dismountPrice").val(tempDismountPrice);
	});
	// 坪数入力(坪)ラジオボタン
	$("#dismountAreaRadio").click(function() {
		$("#dismountPrice").val("");
		$("#dismountPrice").prop("disabled", true);
		$("#dismountArea").prop("disabled", false);
	});

	// 金額入力(円)ラジオボタン
	$("#dismountPriceRadio").click(function() {
		$("#dismountArea").val("");
		$("#dismountArea").prop("disabled", true);
		$("#dismountPrice").prop("disabled", false);
	});

	// OKボタン
	$("#confirmSum").click(
			function(event) {
				// 敷地金額設定項目チェック
				if (!checkNumberWithAlert("敷地金額", deleteComma($("#groundPrice").val()), 13, 0)) {
					return false;
				}

				// 坪数入力(坪)の場合、解体費項目チェック
				if ($("#dismountAreaRadio").is(":checked")) {
					// 数字チェック
					if (!checkNumberWithAlert("坪数入力(坪)", deleteComma($("#dismountArea").val()), 6, 3)) {
						return false;
					}
				}

				// 金額入力(円)の場合、解体費項目チェック
				if ($("#dismountPriceRadio").is(":checked")) {
					// 数字チェック
					if (!checkNumberWithAlert("金額入力(円)", deleteComma($("#dismountPrice").val()), 13, 0)) {
						return false;
					}
				}

				// 敷地金額（変数）
				var groundPrice = 0;
				// 敷地金額（画面表示）
				if ($("#groundPrice").val() == "") {
					document.getElementById("groundPriceDisplay").innerHTML = "¥" + "0";
				} else {
					document.getElementById("groundPriceDisplay").innerHTML = "¥" + $("#groundPrice").val();
					groundPrice = parseInt(deleteComma($("#groundPrice").val()));
				}

				// 解体金額（変数）
				var dismountPrice = 0;
				// 坪数入力(坪)の場合
				if ($("#dismountArea").val() != "") {
					// 解体金額（変数）
					dismountPrice = Math.ceil(parseInt($("#unitPrice").val())
							* parseFloat(deleteComma($("#dismountArea").val())));
					// 解体金額（履歴保存）
					$("#dismountPriceSum").val(dismountPrice);
				}
				// 金額入力(円)の場合
				if ($("#dismountPrice").val() != "") {
					// 解体金額（変数）
					dismountPrice = parseInt(deleteComma($("#dismountPrice").val()));
					// 解体金額（履歴保存）
					$("#dismountPriceSum").val(dismountPrice);
				}
				// 解体金額（画面表示）
				if (dismountPrice == 0) {
					document.getElementById("dismountPriceDisplay").innerHTML = "¥" + "0";
				} else {
					document.getElementById("dismountPriceDisplay").innerHTML = "¥" + format(dismountPrice);
				}
				// 合計金額（画面表示）
				document.getElementById("sumPriceDisplay").innerHTML = "¥"
						+ format(groundPrice + dismountPrice + parseInt(deleteComma($("#housePrice").val())));

			});

	var tempCustomerId = "";
	var tempCustomerName = "";
	// お施主様情報ボタン
	$("#customerSet").click(function() {
		$("#customerModal").modal({
			keyboard : false,
			backdrop : false
		});
		tempCustomerId = $("#customerId").val();
		tempCustomerName = $("#customerName").val();
	});
	// キャンセルボタン
	$("#cancelCustomer").click(function() {
		$("#customerId").val(tempCustomerId);
		$("#customerName").val(tempCustomerName)
	});

	$(document).ready(function() {
		
		if ($("#dismountArea").val() != "") {
			$("#dismountAreaRadio").prop("checked", true);
			$("#dismountArea").prop("disabled", false);
			$("#dismountPriceRadio").prop("checked", false);
			$("#dismountPrice").prop("disabled", true);
		}

		if ($("#dismountPrice").val() != "") {
			$("#dismountAreaRadio").prop("checked", false);
			$("#dismountArea").prop("disabled", true);
			$("#dismountPriceRadio").prop("checked", true);
			$("#dismountPrice").prop("disabled", false);
		}

		if ($("#dismountArea").val() == "" && $("#dismountPrice").val() == "") {
			$("#dismountAreaRadio").prop("checked", true);
			$("#dismountArea").prop("disabled", false);
			$("#dismountPriceRadio").prop("checked", false);
			$("#dismountPrice").prop("disabled", true);
		}

		var sumPrice = 0;
		// 敷地金額
		if ($("#groundPrice").val() == "") {
			document.getElementById("groundPriceDisplay").innerHTML = "¥" + "0";
		} else {
			document.getElementById("groundPriceDisplay").innerHTML = "¥" + $("#groundPrice").val();
			sumPrice = sumPrice + parseInt(deleteComma($("#groundPrice").val()));
		}

		// 建物金額
		document.getElementById("housePriceDisplay").innerHTML = "¥" + format($("#housePrice").val());
		sumPrice = sumPrice + parseInt($("#housePrice").val());

		// 解体金額
		if ($("#dismountPriceSum").val() == "") {
			document.getElementById("dismountPriceDisplay").innerHTML = "¥" + "0";
		} else {
			document.getElementById("dismountPriceDisplay").innerHTML = "¥" + format($("#dismountPriceSum").val());
			sumPrice = sumPrice + parseInt($("#dismountPriceSum").val());
		}

		// 合計金額
		document.getElementById("sumPriceDisplay").innerHTML = "¥" + format(sumPrice);
	});

	// 保存ボタン
	$("#historySave").click(function() {
		// 確認LOG
		$("#historySaveLog").modal({
			keyboard: false,backdrop:false
			  });
		return false;
	});
	
	// はいボタン
	$("#historySaveUpdate").click(function() {
		
		if (!$("#dismountPriceRadio").is(":checked")) {
			$("#dismountPrice").prop("disabled", false);
		}
		if (!$("#dismountAreaRadio").is(":checked")) {
			$("#dismountArea").prop("disabled", false);
		}
		var form = $("#ec002");
		form.attr("action", "../historySave");
		form.submit();
	});
	// 閉じるボタン
	$("#historySaveCancel").click(function() {
		hideMask();
	});
	
	// 保存完了の場合
	if ($("#historySaveFlg").val() == 1){
		$("#historySaveEndLog").modal({
			keyboard: false,backdrop:false
			  });
	}
	
	// 印刷データ送信ボタン
	$("#printer")
			.click(
					function() {
						var transferData = new TransferData();

						if (!$("#dismountPriceRadio").is(":checked")) {
							$("#dismountPrice").prop("disabled", false);
						}
						if (!$("#dismountAreaRadio").is(":checked")) {
							$("#dismountArea").prop("disabled", false);
						}
						transferData.dismountArea = deleteComma($("#dismountArea").val());
						transferData.dismountPrice = deleteComma($("#dismountPrice").val());
						transferData.dismountPriceSum = deleteComma($("#dismountPriceSum").val());
						transferData.groundPrice = deleteComma($("#groundPrice").val());
						transferData.customerId = $("#customerId").val();
						transferData.customerName = $("#customerName").val();
						transferData.housePrice = $("#housePrice").val();

						var request = $.ajax({
							url : "../printer",
							method : "POST",
							data : JSON.stringify(transferData),
							dataType : "json",
							contentType : "application/json; charset=UTF-8"
						});
						$("#alertMessageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML = "メール送信中、数分後でメールを確認してください。";
						$("#alertMessageDialog").modal("toggle");
						hideMask();
					});

	// お施主様ページ発行ボタン
	$("#customerMail")
			.click(
					function() {
						if ($("#customerId").val() == "") {
							hideMask();
							$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML = "「送信先メールアドレス」フィールドを入力してください。";
							$("#messageDialog").modal("toggle");
							return false;
						}
						if ($("#customerName").val() == "") {
							hideMask();
							$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML = "「お施主様名」フィールドを入力してください。";
							$("#messageDialog").modal("toggle");
							return false;
						}

						// 確認LOG
						$("#customerMailLog").modal({
							keyboard: false,backdrop:false
							  });
						return false;
					});
	
	// はいボタン
	$("#customerMailUpdate").click(function() {
		
		if (!$("#dismountPriceRadio").is(":checked")) {
			$("#dismountPrice").prop("disabled", false);
		}
		if (!$("#dismountAreaRadio").is(":checked")) {
			$("#dismountArea").prop("disabled", false);
		}
		var form = $("#ec002");
		form.attr("action", "../customerMail");
		form.submit();
	});
	// 閉じるボタン
	$("#customerMailCancel").click(function() {
		hideMask();
	});
	
	// お施主様ページ発行完了の場合
	if ($("#customerMailFlg").val() == 1){
		$("#customerMailEndLog").modal({
			keyboard: false,backdrop:false
			  });
	}
	
	// ロゴアイコンタップ
	$("#resultLogoImg").on("click", function() {
		if ($("#menuReturnFlg").val() == "1") {
			$("#windowCloseLog").modal({
				keyboard: false,backdrop:false
				  });
		} else if ($("#menuReturnFlg").val() == "2") {
			window.location.href = "../captrue";
		}
		
	});
	// はいボタン
	$("#windowClose").on("click", function() {
		window.close();
	});
	
	// 閉じるボタン
	$("#close").on("click", function() {
		window.close();
	});
	
});
function TransferData() {
	this.groundPrice;
	this.dismountArea;
	this.dismountPrice;
	this.dismountPriceSum;
	this.customerId;
	this.customerName;
	this.housePrice;
}