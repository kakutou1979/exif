$(function() {
	// 前画面からイメージを取得、前画面に表示しているサイズで絵画する
	var canvas = $("#mycanvas")[0];
	var ctx = canvas.getContext('2d');
	var img = new Image();
	img.src = "E:\\nature-4-1.jpg";
	img.onload = function() {
		canvas.width = "1024";
		canvas.height = "1024";
		box = canvas.getBoundingClientRect();
		scalex = canvas.width / img.width;
		scaley = canvas.height / img.height;
		
		ctx.scale(scalex, scaley);
		ctx.drawImage(img, 0, 0);
	};
	// 詳細表示ボタンを押下
	$("#display").on("click", function() {
		if(!$(".selectedBuilding")[0]){
			$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML="プランを選択してください。";
			$("#messageDialog").modal("toggle");
			return false;
		}
		winref = window.open("/wait","お待ちください","menubar=no,location=no,resizable=no,scrollbars=yes,status=no");
		html2canvas($("#displayErea")[0]).then(function(canvas) {
			putObject("displayImg",canvas.toDataURL('image/jpeg', 1),function(){
				let url="../display?planId="+$("#planId").val()+"&groundArea="+$("#tempSiteArea").val();
				winref.location = url;
			});
		});

	});
	// 法令指示のOKを押下
	$("#setLaw").on("click",function(event){
		if(!checkNumberWithAlert("容積率",deleteComma($("#plotRatio").val()),3,3)){
			event.stopPropagation();
			return;
		}
		if(!checkNumberWithAlert("建蔽率",deleteComma($("#buildingCoverage").val()),3,3)){
			event.stopPropagation();
			return;
		}
		if(!checkNumberWithAlert("敷地面積",deleteComma($("#siteArea").val()),6,3,"messageDialog")){
			event.stopPropagation();
			return;
		}
		$("#plotRatio")[0].dataset["plotRatio"]=deleteComma($("#plotRatio").val());
		$("#buildingCoverage")[0].dataset["buildingCoverage"]=deleteComma($("#buildingCoverage").val());
		$("#siteArea")[0].dataset["siteArea"]=deleteComma($("#siteArea").val());
		$("#unit")[0].dataset["unit"]=$("#unit").val();
	});
	// 法令指示を開く
	$("#openLaw").on("click",function(event){
		$("#law").modal({keyboard:false,backdrop:false});
	});
	// 検索条件を開く
	$("#openPosition").on("click",function(event){
		$("#position").modal({keyboard:false,backdrop:false});
	});
	
	// 法令指示のキャンセルを押下
	$("#cancelLaw").on("click",function(event){
		$("#plotRatio").val(format($("#plotRatio")[0].dataset["plotRatio"]));
		$("#buildingCoverage").val(format($("#buildingCoverage")[0].dataset["buildingCoverage"]));
		$("#siteArea").val(format($("#siteArea")[0].dataset["siteArea"]));
		$("#unit").val($("#unit")[0].dataset["unit"]);
	});
	$("[name='position']").each(function(){
		if(this.checked){
			this.dataset["position"]=true;
		}else{
			this.dataset["position"]=false;
		}
	});
	$("[name='roomLayout']").each(function(){
		if(this.checked){
			this.dataset["roomLayout"]=true;
		}else{
			this.dataset["roomLayout"]=false;
		}
	});
	// 検索条件のOKを押下
	$("#setPosition").on("click",function(event){
		if(Array.from($("[name='position']")).every((element)=>{
			return element.checked==false;
		})){
			alert("少なくとも一つ方位を選択してください。");
			return false;
		}
		$("[name='position']").each(function(){
			if(this.checked){
				this.dataset["position"]=true;
			}else{
				this.dataset["position"]=false;
			}
		});
		if(Array.from($("[name='roomLayout']")).every((element)=>{
			return element.checked==false;
		})){
			alert("少なくとも一つ間取りを選択してください。");
			return false;
		}
		$("[name='roomLayout']").each(function(){
			if(this.checked){
				this.dataset["roomLayout"]=true;
			}else{
				this.dataset["roomLayout"]=false;
			}
		});
	});
	// 検索条件のキャンセルを押下
	$("#cancelPosition").on("click",function(event){
		$("[name='position']").each(function(){
			if(this.dataset["position"]=="true"){
				this.checked = true;
			}else{
				this.checked = false;
			}
		});
		$("[name='roomLayout']").each(function(){
			if(this.dataset["roomLayout"]=="true"){
				this.checked = true;
			}else{
				this.checked = false;
			}
		});
	});
	
	

	
	// プラン選択画面を呼び出す
	$("#selectPlan").on("click", function() {
		var htmstr;
		var container = $("#planDialog");
		container.children().remove();
		for (var i = 0; i < 30; i++) {
			htmstr = `<div class='col-sm-6 col-md-6 col-xl-4' data-planId='01'>
				<div class='caption'>サンプル</div> 
				<a href='#'><img class='img-thumbnail' src='./img/before/img100.jpg'></a>
				<div class='figure-caption'>建物金額:</div>
				<div class='figure-caption'>建築面積:</div>
				<div class='figure-caption'>延床面積:</div>
				<div class='figure-caption'>間取り:</div>
				</div>`;
				container.append(htmstr);
		}
				
		$("#selectedPlans").modal({keyboard:false,backdrop:false});
		
		// プラン選択画面で選択されるプランのCSSを追加する
		$("#planDialog>div").each(function() {
			$(this).on("click", function(event) {
				if (selectedPlans && selectedPlans.length > 0) {
					selectedPlans[0].removeClass("plan-active");
				}
				$(this).addClass("plan-active");
				selectedPlans = [];
				selectedPlans.push($(this));
			});
		});
	});
	
	// プラン選択を押下
	$("#planSelected").on("click",function(){
		var selectedPlan = $(".plan-active");
		if(selectedPlan[0]){
			var div = document.createElement('div');
			div.className = "selectedBuilding";
			let shapeCanvas = $("#shapeCanvas")[0];
			shapeCanvas.width = Number(selectedPlan[0].dataset["sizewidth"]);
			shapeCanvas.height = Number(selectedPlan[0].dataset["sizeheight"]);
			let ctx = shapeCanvas.getContext('2d');
			let pointlist = JSON.parse(selectedPlan[0].dataset["cordinatelist"]);
	        ctx.beginPath();
	        ctx.lineCap = "round";
	        let color = selectedPlan[0].dataset["color"];
	        ctx.fillStyle = `rgb(${color})`;
	        for(i=0;i<pointlist.length;i++){
	            if(i==0){
	                ctx.moveTo(pointlist[i].x,pointlist[i].y);
	            }else{
	                ctx.lineTo(pointlist[i].x,pointlist[i].y);

	                if(i==pointlist.length-1){
	                    ctx.lineTo(pointlist[0].x,pointlist[0].y);
	                }

	            }
	        }
	        ctx.fill();
			img = new Image();
//			img.src = selectedPlan[0].dataset["houseshape"];
			img.src = shapeCanvas.toDataURL("'image/png'");
			img.onload = function() {
				div.appendChild(this);
				div.style.left = (Number(selectedPlan[0].dataset["cordinatex"]) - this.width / 2+canvas.getBoundingClientRect().left) + "px";
				div.style.top = (Number(selectedPlan[0].dataset["cordinatey"]) - this.height / 2+canvas.getBoundingClientRect().top) + "px";
			};
			$("#planId").val(selectedPlan[0].dataset["planid"]);
			$(div).on("touchstart", function() {
				event.preventDefault();
				touchImg = img;
				smallImg = img;
				moveDiv = this;
			});
			$(".selectedBuilding").remove();
			$("#area").parent().append(div);
			$("#tempSiteArea").val(deleteComma($("#siteArea").val()) * ($("#unit").val() == 1 ? 1:1/0.3025));
			var container = $("#planDialog");
			container.html("");
		}else{
			alert("プランを選択してください。");
			return false;
		}
	})
	// プランキャンセルを押下
	$("#planCancel").on("click",function(){
		var container = $("#planDialog");
		container.html("");
	})
	
	var infoDialogFlg = false;
	// 駐車場イメージのドラッグを開始するとき、移動するための隠しDIVを作成
	$("img[id^=shortc]").on("touchstart", function() {
		event.preventDefault();
		let touchCanvas=$("#canvas_"+event.target.id)[0];
		let touchCtx = touchCanvas.getContext('2d');
		touchCanvas.width = this.width;
		touchCanvas.height = this.height;
		touchCtx.drawImage(this,0,0);
		touchImg = new Image();
		
		//alert(this.src);
		
		//touchImg.src = touchCanvas.toDataURL("'image/jpeg'");
		
		touchImg.src = this.src;
		
		touchImg.dataset["size"] = document.getElementById(event.target.id).dataset["size"];
		touchImg.onload = function(){
			let div = document.createElement('div');
			div.className = "touchDiv";
			div.appendChild(this);
			let array = new Uint32Array(1);
			window.crypto.getRandomValues(array);
			div.id = array[0];
			$(div).hide();
			$("#area").parent().append(div);
			moveDiv = div;
			infoDialogFlg = true;
		};

	});
	// 指が滑るとき、駐車場のドラッグ、駐車場の回転を判断し、対応の動作を実施する、
	$("body").on("touchmove", function() {
		if (!moveDiv) {
			return false;
		}
		if (isRotating) {
			rotate(moveDiv, event);
			return true;
		}
		if (!smallImg) {
			smallImg = new Image();
			smallImg.src = touchImg.src;
			smallImg.onload = function(){
				let size = Number(touchImg.dataset["size"]);
//				if(!isNaN(size)) {
//					size = (size/smallImg.height)/Number(sessionStorage["ratio"]);
//				}else{
//					size = (5/smallImg.height)/Number(sessionStorage["ratio"]);;
//				}
				size = (size/smallImg.height)/Number(sessionStorage["ratio"]);
				let tempHeight = smallImg.height;
				smallImg.width = touchImg.width * scalex * size;
				if (tempHeight == smallImg.height) {
					smallImg.height = touchImg.height * scaley * size;
				}
			}
		}
		var touches = event.changedTouches;
		if (isInCanvas(event)) {
			moveDiv.removeChild(touchImg);
			moveDiv.appendChild(smallImg);
			touchImg = smallImg;
// $(".touchDiv").each(function() {
// if (moveDiv.id != this.id && isOnOther(moveDiv, this)) {
// moveDiv.style.backgroundColor = "red";
// moveDiv.style.opacity = "0.5";
// return false;
// } else {
// moveDiv.style.backgroundColor = "";
// moveDiv.style.opacity = "1";
// }
// })
		}
		moveDiv.style.position = "absolute";
		moveDiv.style.left = (touches[0].clientX + window.scrollX - touchImg.width / 2) + "px";
		moveDiv.style.top = (touches[0].clientY + window.scrollY - touchImg.height / 2) + "px";
		$(moveDiv).show();
		moveDiv.dataset["lx"] = touches[0].clientX + window.scrollX - touchImg.width / 2;
		moveDiv.dataset["ly"] = touches[0].clientY + window.scrollY - touchImg.height / 2;
		moveDiv.dataset["width"] = touchImg.width;
		moveDiv.dataset["height"] = touchImg.height;
		moveDiv.dataset["innerAngle"] = 360 * Math.atan(touchImg.height / touchImg.width) / (2*Math.PI);
	});

	// 指を解くとき、駐車場をドラッグしている場合、駐車場の表示位置を設定し、駐車場イメージのイベントをバインディング
	$("body").on("touchend", function() {
		var touches = event.changedTouches;
		if (!moveDiv) {
			return true;
		}
		if(infoDialogFlg && isInCanvas(event)){
			$("#infoDialog").modal("toggle");
			infoDialogFlg = false;
		}
		if( moveDiv.children[0].width == 0 ){
			$("#area").parent()[0].removeChild(moveDiv);
		} else {
			if (isInCanvas(event)) {
				var startx = moveDiv.dataset["startx"];
				var starty = moveDiv.dataset["starty"];
				var cx = Number(moveDiv.dataset["cx"]);
				var cy = Number(moveDiv.dataset["cy"]);
				if (startx && starty) {
					if (moveDiv.style.backgroundColor == "red") {
						moveDiv.style.left = startx + "px";
						moveDiv.style.top = starty + "px";
						moveDiv.style.backgroundColor = "";
						moveDiv.style.opacity = "1";
					} else {
						if (!isRotating) {
							moveDiv.dataset["cx"] = touches[0].clientX + window.scrollX;
							moveDiv.dataset["cy"] = touches[0].clientY + window.scrollY;
							moveDiv.dataset["rx"] = Number(moveDiv.dataset["rx"]) + touches[0].clientX + window.scrollX - cx;
							moveDiv.dataset["ry"] = Number(moveDiv.dataset["ry"]) + touches[0].clientY + window.scrollY - cy;
						}
					}
				} else {
					if (moveDiv.style.backgroundColor == "red") {
						$("#area").parent()[0].removeChild(moveDiv);
					} else {
						$(moveDiv).on("touchstart", function(event) {
							moveDiv = this;
							event.preventDefault();
							if (isOnRightTop(this, event)) {
								return true;
							}
							thouches = event.changedTouches;
							touchImg = this.firstChild;
							smallImg = touchImg;
							moveDiv.dataset["startx"] = moveDiv.style.left.replace("px", "");
							moveDiv.dataset["starty"] = moveDiv.style.top.replace("px", "");
						});
						if (!isRotating) {
							moveDiv.dataset["rx"] = Number(moveDiv.dataset["lx"]) + touchImg.width;
							moveDiv.dataset["ry"] = moveDiv.dataset["ly"];
							moveDiv.dataset["cx"] = touches[0].clientX + window.scrollX;
							moveDiv.dataset["cy"] = touches[0].clientY + window.scrollY;
						}

					}

				}
			} else {
				$("#area").parent()[0].removeChild(moveDiv);
			}
		}

		isRotating = false;
		touchImg = null;
		smallImg = null;
		moveDiv = null;

	});
});

// X方向のスケール
var scalex;
// Y方向のスケール
var scaley;
// タッチするイメージ
var touchImg;
// ドラッグするイメージ
var smallImg;
// ドラッグするイメージを格納するDIV
var moveDiv;
// 回転するかどうか
var isRotating;
// 選択したプラン
var selectedPlans;
// canvasの枠
var box;
// 駐車場座標
var cars;
/*
 * 指はCANVASの範囲にあるかどうかを判断する
 */
function isInCanvas(event) {
	var touches = event.changedTouches;
	var canvas = $("#mycanvas")[0];
	var ctx = canvas.getContext('2d');
	var px = touches[0].clientX + window.scrollX;
	var py = touches[0].clientY + window.scrollY;
	var cpx = canvas.offsetLeft + canvas.offsetParent.offsetLeft;
	var cpy = canvas.offsetTop + canvas.offsetParent.offsetTop;
	if (px >= (cpx + touchImg.width / 2)
			&& px <= (cpx + canvas.offsetWidth - touchImg.width / 2)
			&& py >= (cpy + touchImg.height / 2)
			&& py <= (cpy + canvas.offsetHeight - touchImg.height / 2)) {
		return true;
	} else {
		return false;
	}
}
/*
 * 他の駐車場イメージと重なり合うかどうか
 */
function isOnOther(m1, m2) {
	if ((m1.offsetTop + m1.offsetHeight) < m2.offsetTop
			|| (m1.offsetLeft) > (m2.offsetLeft + m2.offsetWidth)
			|| m1.offsetTop > (m2.offsetTop + m2.offsetHeight)
			|| (m1.offsetLeft + m1.offsetWidth) < m2.offsetLeft) {
		return false;
	} else {
		return true;
	}
}
/*
 * 指は駐車場の右上にあるかどうか
 */
function isOnRightTop(div, event) {
	if (div.className=="selectedBuilding") {
		return;
	}
	var touches = event.changedTouches;
	if (Math.abs(touches[0].clientX + window.scrollX - Number(moveDiv.dataset["rx"])) < 10
			&& Math.abs(touches[0].clientY + window.scrollY - Number(moveDiv.dataset["ry"])) < 10) {
		isRotating = true;
	} else {
		isRotating = false;
	}
}
/*
 * 指の移動によって、回転する
 */
function rotate(div, event) {
	var touches = event.changedTouches;
	var px = touches[0].clientX + window.scrollX;
	var py = touches[0].clientY + window.scrollY;
	var cx = Number(moveDiv.dataset["cx"]);
	var cy = Number(moveDiv.dataset["cy"]);
	var innerAngle = Number(moveDiv.dataset["innerAngle"]);
	var plus = 1;
	var plusx = 1;
	var plusy = 1;
	var countAngle;
	if (px >= cx && py < cy) {
		plus = 0;
	} else if (px < cx && py <= cy) {
		plus = -180;
	} else if (px < cx && py > cy) {
		plus = 180;
	} else {
		plus = -360;
	}
	var pointAngle = 360 * Math.atan(Math.abs(cy - py) / Math.abs(cx - px))　/　(2*Math.PI);
	var angle = Math.abs(pointAngle + plus) * -1 + innerAngle;
	pointAngle = Math.abs(pointAngle + plus);
	div.style.transform = "rotate(" + angle + "deg)";
	var w = Number(moveDiv.dataset["width"]) / 2;
	var h = Number(moveDiv.dataset["height"]) / 2;
	var r = Math.sqrt(Math.pow(h, 2) + Math.pow(w, 2));
	moveDiv.dataset["angle"] = pointAngle;
	var rPoint = calculatePosition(pointAngle, r, cx, cy);
	moveDiv.dataset["rx"] = rPoint[0];
	moveDiv.dataset["ry"] = rPoint[1];
}
/*
 * 角で座標を算出
 */
function calculatePosition(pointAngle, r, cx, cy) {

	var point = [];
	if (Math.abs(pointAngle) <= 180) {
		pointAngle = Math.abs(pointAngle) * -1;
	} else {
		pointAngle = 360 - Math.abs(pointAngle);
	}
	if (pointAngle < 0 && pointAngle >= -90) {
		plusx = 1;
		plusy = -1;
	} else if (pointAngle >= -180 && pointAngle < -90) {
		plusx = -1;
		plusy = -1;
	} else if (pointAngle > 90 && pointAngle <= 180) {
		plusx = -1;
		plusy = 1;
	} else if (pointAngle > 0 && pointAngle <= 90) {
		plusx = 1;
		plusy = 1;
	}
	point[0] = cx + Math.abs(Math.cos(pointAngle * Math.PI / 180) * r) * plusx;
	point[1] = cy + Math.abs(Math.sin(pointAngle * Math.PI / 180) * r) * plusy;
	return point;
}

/*
 * 計算用角を算出
 */
function calculateAngle(angle) {
	if (angle > 360) {
		return angle - 360;
	} else {
		return angle;
	}
}
/*
 * サーバへ送信するデータ
 */
function TransferData() {
	// 駐車場座標
	this.cars;
	// 容積率
	this.plotRatio;
	// 建蔽率
	this.buildingCoverage;
	// 敷地面積
	this.siteArea;
	// 方位
	this.positions;
	// 間取り
	this.roomLayouts;
	// 敷地座標
	this.landPoints;
	// 長さ比率
	this.ratio;
}