$(function() {
	
	// 登録FLG
	var updateFlg = $("#updateFlg").val();
	// 登録完了の場合
	if (updateFlg == 2){
		$('#endLog').modal({
			keyboard: false,backdrop:false
			  });
	}
	
	// レコード存在COUNT
	var recordCount = document.getElementById('urlResult').children.length;
	// レコード追加存在しないの場合、
	if (recordCount == 0) {
		// INDEX設定
		var index = 0;
	    $("#urlIndex").val(index);
		// レコード追加
		addTableRow();
	} else {
		$("#urlIndex").val(recordCount);
	}
	
	// 設定ボタン
	$("#btn_setUrl").bind("click", function(event) {
		$("#updateFlg").val('0');

		var lineNo = 1;
		var errorFlg = 0;
		$("#urlResult input[name$='title']").each(function() {
			var title = this.value;
			
			   if(title == ""){
					$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML="明細行「" + lineNo +"」の「タイトル」フィールドを入力してください。";
					$("#messageDialog").modal("toggle");
					event.stopPropagation();
					errorFlg = 1;
			 }
			lineNo= Number(lineNo) +  Number(1);
		})
		if (errorFlg == 1) {
			return false;
		}
		
		lineNo = 1;
		errorFlg = 0;
		$("#urlResult input[name$='url']").each(function() {
			var url = this.value;
			   if(url == ""){
					$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML="明細行「" + lineNo +"」の「URL」フィールドを入力してください。";
					$("#messageDialog").modal("toggle");
					event.stopPropagation();
					errorFlg = 1;
			 }
			lineNo= Number(lineNo) +  Number(1);
		})
		if (errorFlg == 1) {
			return false;
		}

		// 確認LOG
		$("#updateLog").modal({
			keyboard: false,backdrop:false
			  });
		return false;
	});
	
	// はいボタン
	$("#btn_update").click(function() {
		var form = $("#ea007");
		form.attr("action", "./addUrl");
		form.submit();
	})
	
	// 削除ボタン
	$('#para_table').on('click', 'button', function() {
		var td = $(this);
		td.parent().parent().remove();

        var title= $("#para_table input[name$='title']");
        
        var index = 0;
        title.each(function() {
            $(this).attr("name", "urlList[" + index + "].title");
            index++;
          });
        
        var url= $("#para_table input[name$='url']");
        
        index = 0;
        url.each(function() {
            $(this).attr("name", "urlList[" + index + "].url");
            index++;
          });
        
        var urlIndex = $("#urlIndex").val();
    	urlIndex = Number(urlIndex) - Number(1);
    	$("#urlIndex").val(urlIndex);
	})

	// 追加ボタン
	$("#btn_add").bind("click", function(event) {
		addTableRow();
	});
	
	// 確認メッセージ
	var modalFlg = $("#modalFlg").val();
	if (modalFlg == "true") {
		$("#urlUpdateConfirm").modal({keyboard:false,backdrop:false});
	}

	// はいボタン
	$("#updateUrl").bind("click", function(event) {
		var form = $("#ea007");
		form.attr("action", "./updateUrl");
		form.submit();
	});
})

/**
 * 
 * レコード追加
 * 
 */
function addTableRow()
{
	var urlIndex = $("#urlIndex").val();  
	var table = $("#para_table");
	
	var tr = $("<tr>"
			+ "<td style='text-align: center;width: 40%; word-break: break-all'>"
			+ "<input type='text' class='form-control'"+" name='urlList["+ urlIndex +"].title' placeholder='タイトル設定' required='required' maxlength='20'>"
			+ "</td>"
			+ "<td style='text-align: center;width: 50%; word-break: break-all'>"
			+ "<input type='text' class='form-control'"+" name='urlList["+ urlIndex +"].url' placeholder='URL設定' required='required'  maxlength='200'>"
			+ "</td>"
			+ "<td style='text-align: center;width: 10%; word-break: break-all'><button type='button'  class='btn list-group-item-primary' id='btn_del' >"
			+ "削除" + "</button></td></tr>");
	
	table.append(tr);
	urlIndex = Number(urlIndex) + Number(1);
	$("#urlIndex").val(urlIndex);
}