
$(function() {
	
	var preUnitPrice = $("#preUnitPrice").val();
	if (preUnitPrice != "") {
		$("#updateConfirm").modal({keyboard:false,backdrop:false});
	}
	
	// 登録FLG
	var updateFlg = $("#updateFlg").val();
	// 登録完了の場合
	if (updateFlg == 1){
		$('#endLog').modal({
			keyboard: false,backdrop:false
			  });
	}
	
	// 確認ボタン
	$("#confirm").on("click",function(event){
		
		if($("#unitpriceset").val() == ""){
				$("#messageDialog > .modal-dialog > .modal-content > .modal-body > .form-group > label")[0].innerHTML="「単価」フィールドを入力してください。";
				$("#messageDialog").modal("toggle");
				return false;
		 }
		
		if(!checkNumberWithModal("単価",deleteComma($("#unitpriceset").val()),13,0,"messageDialog")){
			return false;
		}
		
		$("#unitpriceset")[0].dataset["unitpriceset"]=deleteComma($("#unitpriceset").val());
		
		// 確認LOG
		$("#updateLog").modal({
			keyboard: false,backdrop:false
			  });
		return false;
	});
	
	// はいボタン
	$("#btn_update").click(function() {
		var form = $("#ea006");
		form.attr("action", "./priceSetConfirm");
		form.submit();
	})
	
	//　はいボタン
	$("#update").bind("click", function(event) {
		
		// 単価
		$("#unitpriceset").val($("#preUnitPrice").val());
		// 種別
		$("#type").val($("#preType").val());
		
		var form = $("#ea006");
		form.attr("action", "./priceSetUpdate");
		form.submit();
	});
	
	// キャンセルボタン
	$("#cancel").bind("click", function(event) {
		
		// 単価
		$("#unitpriceset").val(format(preUnitPrice));
	});
});
