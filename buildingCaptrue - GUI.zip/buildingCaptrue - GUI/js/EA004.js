$(function() {
	
	$("tr[id^=btn_detailed]").bind("click", function(event) {
		var planId = this.children[3].childNodes[2].value;
		$("#planIdParam").val(planId);
		
		var form = $("#ea004");
		form.attr("action", "./planDetailed");
		form.submit();
	});
	
	$(document).ready(function() {
		// 建物金額(円)設定
		var housePrice = $("#plan_table label[name$='housePrice']");
		housePrice.each(function() {
			$(this).text(format($(this).text()));
		});
		
		// 建築面積（㎡）設定
		var hoseArea = $("#plan_table label[name$='hoseArea']");
		hoseArea.each(function() {
			$(this).text(format($(this).text()));
		});
	});
})